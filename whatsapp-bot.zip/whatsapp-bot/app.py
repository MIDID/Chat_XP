import os
from flask import Flask, request, jsonify
from datetime import datetime
import requests
from waitress import serve
from dotenv import load_dotenv
from pymongo import MongoClient, server_api
from pymongo.server_api import ServerApi
import sys
import logging
import certifi
from pathlib import Path
from bson import ObjectId

# ========== INITIAL SETUP ==========
logging.basicConfig(
    level=logging.DEBUG,  # Changed to DEBUG for more detailed logs
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger(__name__)

# Load environment variables
env_path = Path(__file__).parent / '.env'
load_dotenv(env_path)

app = Flask(__name__)
logger.info("Flask app initialized.")

# ========== CONFIGURATION ==========
WHATSAPP_TOKEN = os.getenv('WHATSAPP_TOKEN', '').strip()
WHATSAPP_NUMBER_ID = os.getenv('WHATSAPP_NUMBER_ID', '').strip()
VERIFY_TOKEN = os.getenv('VERIFY_TOKEN', 'default_verify_token').split('#')[0].strip()
MONGO_URI = "mongodb+srv://24mcaa33:5pPed5IgazkSalwo@cluster0.uqkbjdp.mongodb.net/chat_xp?retryWrites=true&w=majority"
DB_NAME = "chat_xp"
SERVER_URL = os.getenv('SERVER_URL', '').strip()

# ========== CREDENTIAL VALIDATION ==========
logger.info("\n=== Credential Validation ===")
if not WHATSAPP_TOKEN:
    logger.error("❌ WHATSAPP_TOKEN is not set in environment variables")
    sys.exit(1)
else:
    logger.info(f"WHATSAPP_TOKEN: {'EA...' + WHATSAPP_TOKEN[-6:] if WHATSAPP_TOKEN.startswith('EA') else 'Invalid format'}")

if not WHATSAPP_NUMBER_ID:
    logger.error("❌ WHATSAPP_NUMBER_ID is not set in environment variables")
    sys.exit(1)
else:
    logger.info(f"WHATSAPP_NUMBER_ID: {WHATSAPP_NUMBER_ID}")

if not WHATSAPP_TOKEN.startswith('EA') or len(WHATSAPP_TOKEN) < 150:
    logger.error("❌ WHATSAPP_TOKEN appears invalid - should start with 'EA' and be ~200 chars")
    sys.exit(1)

# ========== MONGODB CONNECTION ==========
try:
    logger.info("\nConnecting to MongoDB...")
    client = MongoClient(
        MONGO_URI,
        tls=True,
        tlsCAFile=certifi.where(),
        server_api=ServerApi('1'),
        connectTimeoutMS=10000,
        serverSelectionTimeoutMS=10000
    )
    client.admin.command('ping')
    logger.info("✅ MongoDB connected successfully")
    
    db = client[DB_NAME]
    expenses_collection = db['expenses']
    user_states_collection = db['user_states']
    
    expenses_collection.create_index([('sender_id', 1), ('timestamp', -1)])
    user_states_collection.create_index([('user_id', 1)], unique=True)

except Exception as e:
    logger.error(f"❌ MongoDB connection failed: {str(e)}")
    sys.exit(1)

# ========== MESSAGE PROCESSING FUNCTIONS ==========
def process_message(sender, message):
    """Main message processing function"""
    message = message.lower().strip()
    sender_id = ''.join([c for c in sender if c == '+' or c.isdigit()])
    
    logger.info(f"💬 Processing message from {sender_id[:4]}...{sender_id[-4:]}: '{message}'")

    if message == "summary":
        send_summary(sender_id)
    elif message == "delete last":
        delete_last_expense(sender_id)
    elif message == "help":
        send_help_message(sender_id)
    else:
        user_state = user_states_collection.find_one({'user_id': sender_id})
        
        if user_state and user_state.get('state') == 'awaiting_category':
            handle_category_selection(sender_id, message, user_state)
        else:
            handle_amount_input(sender_id, message)

def handle_category_selection(sender_id, message, user_state):
    """Handle category selection from user"""
    try:
        categories = ["groceries", "food", "petrol", "bills", "shopping", "other"]
        category_num = int(message)
        
        if 1 <= category_num <= len(categories):
            expense_record = {
                "sender_id": sender_id,
                "amount": float(user_state['temp_amount']),
                "category": categories[category_num - 1],
                "timestamp": datetime.now(),
                "description": user_state.get('temp_description', '')
            }
            expenses_collection.insert_one(expense_record)
            send_message(sender_id, f"✅ Added ₹{user_state['temp_amount']} to {categories[category_num - 1].capitalize()}")
            user_states_collection.delete_one({'user_id': sender_id})
        else:
            send_message(sender_id, f"⚠ Please select 1-{len(categories)}")
    except ValueError:
        send_message(sender_id, "⚠ Please enter a valid number")

def handle_amount_input(sender_id, message):
    """Handle amount input from user"""
    try:
        parts = message.split(' ', 1)
        amount = float(parts[0])
        description = parts[1] if len(parts) > 1 else ""
        
        user_states_collection.update_one(
            {'user_id': sender_id},
            {
                '$set': {
                    'state': 'awaiting_category',
                    'temp_amount': amount,
                    'temp_description': description
                }
            },
            upsert=True
        )
        
        category_menu = "\n".join([
            "1. Groceries 🛒",
            "2. Food & Dining 🍽",
            "3. Petrol ⛽",
            "4. Bills 💳",
            "5. Shopping 🛍",
            "6. Other ✨"
        ])
        
        send_message(sender_id, f"💰 Amount: ₹{amount:.2f}\n\nSelect category:\n{category_menu}")
    except ValueError:
        send_message(sender_id, "⚠ Please enter a valid amount (e.g. 100 or '100 for dinner')")

def send_summary(sender_id):
    """Send monthly expense summary to user"""
    current_month = datetime.now().strftime("%Y-%m")
    start_date = datetime.strptime(current_month, "%Y-%m")
    next_month = start_date.replace(month=start_date.month+1) if start_date.month < 12 else start_date.replace(year=start_date.year+1, month=1)
    
    monthly_expenses = list(expenses_collection.find({
        'sender_id': sender_id,
        'timestamp': {'$gte': start_date, '$lt': next_month}
    }).sort('timestamp', -1))

    if not monthly_expenses:
        send_message(sender_id, "📭 No expenses this month")
        return

    total = sum(e['amount'] for e in monthly_expenses)
    breakdown = {}
    for e in monthly_expenses:
        breakdown[e['category']] = breakdown.get(e['category'], 0) + e['amount']
    
    summary = [
        "📊 Monthly Summary",
        f"Total: ₹{total:.2f}",
        *[f"- {cat.title()}: ₹{amt:.2f} ({(amt/total)*100:.1f}%)" 
         for cat, amt in breakdown.items()],
        "\nRecent expenses:",
        *[f"• ₹{e['amount']:.2f} - {e['category']} ({e['timestamp'].strftime('%d %b')})"
          for e in monthly_expenses[:5]]
    ]
    
    send_message(sender_id, "\n".join(summary))

def delete_last_expense(sender_id):
    """Delete the user's last expense"""
    try:
        last_expense = expenses_collection.find_one(
            {'sender_id': sender_id},
            sort=[('timestamp', -1)]
        )
        
        if last_expense:
            expenses_collection.delete_one({'_id': last_expense['_id']})
            send_message(sender_id, f"🗑 Deleted: ₹{last_expense['amount']} for {last_expense['category']}")
        else:
            send_message(sender_id, "No expenses found to delete")
    except Exception as e:
        logger.error(f"Error deleting last expense: {str(e)}")
        send_message(sender_id, "Error deleting last expense")

def send_help_message(sender_id):
    """Send help instructions to user"""
    help_text = """
💡 *Expense Tracker Help* 💡

*Add Expense*:
- Just send the amount (e.g., "100")
- Or amount with description (e.g., "100 for dinner")

*Commands*:
- *summary* - Show monthly summary
- *delete last* - Remove your last expense
- *help* - Show this help message

Categories:
1. Groceries
2. Food & Dining
3. Petrol
4. Bills
5. Shopping
6. Other
"""
    send_message(sender_id, help_text)

def send_message(recipient, message):
    """Send message via WhatsApp API with comprehensive error handling"""
    if not WHATSAPP_TOKEN or not WHATSAPP_NUMBER_ID:
        logger.error("❌ Missing WhatsApp credentials")
        return False

    url = f"https://graph.facebook.com/v17.0/{WHATSAPP_NUMBER_ID}/messages"
    headers = {
        "Authorization": f"Bearer {WHATSAPP_TOKEN}",
        "Content-Type": "application/json"
    }
    payload = {
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": recipient,
        "type": "text",
        "text": {
            "preview_url": False,
            "body": message
        }
    }

    try:
        logger.debug(f"🔗 API URL: {url}")
        logger.debug(f"📝 Headers: {headers}")
        logger.debug(f"📦 Payload: {payload}")
        
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        response.raise_for_status()
        
        logger.info(f"✅ Message sent to {recipient[:4]}...{recipient[-4:]}")
        return True
        
    except requests.exceptions.HTTPError as e:
        logger.error(f"❌ HTTP Error: {str(e)}")
        if e.response:
            error_data = e.response.json()
            logger.error(f"📛 Error Details: {error_data}")
            
            if e.response.status_code == 401:
                logger.error("""
🔴 CRITICAL AUTHENTICATION FAILURE 🔴
Possible solutions:
1. REGENERATE your WhatsApp token in Meta Developer Portal
2. Verify PHONE NUMBER ID matches exactly
3. Check token EXPIRATION DATE
4. Ensure BUSINESS ACCOUNT is properly linked
5. Verify PERMISSIONS include whatsapp_business_messaging
""")
                # Additional debug info
                logger.debug(f"Current WHATSAPP_NUMBER_ID: {WHATSAPP_NUMBER_ID}")
                logger.debug(f"Current WHATSAPP_TOKEN prefix: {WHATSAPP_TOKEN[:10]}...")
                
        return False
        
    except Exception as e:
        logger.error(f"⚠ Unexpected error: {str(e)}", exc_info=True)
        return False

# ========== WEBHOOK ENDPOINTS ==========
@app.route('/webhook', methods=['GET'])
def verify_webhook():
    mode = request.args.get('hub.mode')
    token = request.args.get('hub.verify_token')
    challenge = request.args.get('hub.challenge')

    logger.info(f"\n🔍 Webhook Verification Request:")
    logger.info(f"  Mode: '{mode}'")
    logger.info(f"  Received Token: '{token}'")
    logger.info(f"  Expected Token: '{VERIFY_TOKEN}'")

    if mode == 'subscribe' and token == VERIFY_TOKEN:
        logger.info("✅ Webhook verified successfully!")
        return challenge, 200
    
    error_details = {
        "status": "error",
        "received_mode": mode,
        "received_token": token,
        "expected_token": VERIFY_TOKEN
    }
    
    if mode != 'subscribe':
        error_msg = f"Invalid mode: '{mode}' (expected 'subscribe')"
        logger.error(f"❌ {error_msg}")
        error_details["message"] = error_msg
    else:
        error_msg = f"Token mismatch (received: '{token}', expected: '{VERIFY_TOKEN}')"
        logger.error(f"❌ {error_msg}")
        error_details["message"] = error_msg
    
    return jsonify(error_details), 403

@app.route('/webhook', methods=['POST'])
def handle_webhook():
    try:
        data = request.get_json()
        logger.debug(f"📩 Incoming Webhook Data: {data}")

        if 'object' not in data or data['object'] != 'whatsapp_business_account':
            return jsonify({"status": "error", "message": "Invalid webhook format"}), 400

        for entry in data.get('entry', []):
            for change in entry.get('changes', []):
                if 'messages' in change.get('value', {}):
                    for message in change['value']['messages']:
                        if message['type'] == 'text':
                            process_message(
                                sender=message['from'],
                                message=message['text']['body']
                            )
        
        return jsonify({"status": "success"}), 200
    except Exception as e:
        logger.error(f"⚠ Webhook processing error: {str(e)}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 500

# ========== CREDENTIAL TESTING ENDPOINT ==========
@app.route('/test_credentials', methods=['GET'])
def test_credentials():
    """Endpoint to test WhatsApp API credentials"""
    test_url = f"https://graph.facebook.com/v17.0/{WHATSAPP_NUMBER_ID}"
    headers = {"Authorization": f"Bearer {WHATSAPP_TOKEN}"}
    
    try:
        response = requests.get(test_url, headers=headers)
        response.raise_for_status()
        return jsonify({
            "status": "success",
            "message": "Credentials are valid",
            "phone_number_info": response.json()
        })
    except Exception as e:
        error_response = {
            "status": "error",
            "message": str(e),
            "credentials_used": {
                "number_id": WHATSAPP_NUMBER_ID,
                "token_prefix": WHATSAPP_TOKEN[:10] + "..."
            }
        }
        if 'response' in locals():
            error_response["api_response"] = response.json()
        return jsonify(error_response), 401

# ========== SERVER STARTUP ==========
if __name__ == '__main__':
    logger.info("\n🚀 Starting Server =========")
    logger.info(f"🌐 Webhook URL: {SERVER_URL}/webhook" if SERVER_URL else "SERVER_URL not set")
    logger.info(f"💾 Database: {DB_NAME}")
    logger.info(f"🔐 Test credentials endpoint: {SERVER_URL}/test_credentials")
    serve(app, host='0.0.0.0', port=3000)