use('chat_xp');

// Test if connected
db.runCommand({ ping: 1 });

// Create collections if missing
if (!db.getCollectionNames().includes('expenses')) {
  db.createCollection('expenses');
}
if (!db.getCollectionNames().includes('user_states')) {
  db.createCollection('user_states');
}

// Insert test data
db.expenses.insertOne({
  sender_id: "1234567890",
  amount: 100,
  category: "food",
  timestamp: new Date()
});

// Verify
db.expenses.find().toArray();